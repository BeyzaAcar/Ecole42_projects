git log -n 5 --format=%H
